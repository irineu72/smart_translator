require 'json'

def getFile
    begin  # Ler o arquivo que será traduzido
        file_to_transalate = File.read('pt.json')
        input_translate_object = JSON.parse(file_to_transalate)
        return input_translate_object
    rescue StandardError => e
        if e.to_s.include?("unexpected token at")
            puts " ## Formato Incorreto do arquivo json"
        else
            if e.to_s.include?("No such file or directory")
                puts " ## Arquivo não encontrado"
            else
                puts e.to_s
            end
        end
    end 
end


def descer_nivel_hash (valor_input)
    valor_input.each do |chave, valor|
        if valor.class.to_s == 'Hash'
            retorno = descer_nivel_hash(valor)
            valor_input[chave] = retorno
        else
            if valor.class.to_s == 'String'
                # Traduzir este valor
                valorTraduzido = traduzirString(valor)
                # Atualizar Arvore com novo valor traduzido
                valor_input[chave] = valorTraduzido
            end
        end
    end

    return valor_input
end

def traduzirString (string_input)
    begin  # Ler o arquivo que será traduzido
        require "uri"
        require "net/http"

        url = URI("https://api.cognitive.microsofttranslator.com/translate?api-version=3.0&from=pt&to=fr")

        https = Net::HTTP.new(url.host, url.port)
        https.use_ssl = true

        request = Net::HTTP::Post.new(url)
        request["Ocp-Apim-Subscription-Key"] = "insira_chave" # Chave Subscription
        request["Ocp-Apim-Subscription-Region"] = "global"
        request["Content-type"] = "application/json"
        request["X-ClientTraceId"] = "f6b795c0-6662-4ad6-8308-3f00482162fc"
        request.body = "[{ \"text\": \"#{string_input.to_s}\" }]\r\n"

        response = https.request(request)
        puts response
        valorTraduzido = JSON.parse(response.body)[0]['translations'][0]['text'].to_s
        return valorTraduzido
    
    rescue StandardError => e
        valorTraduzido = response.body.to_s
        return valorTraduzido
    end

end

# ----- MAIN ----- #

# Ler JSON e parsear
objeto_traduzir = getFile

# Percorrer JSON
objeto_traduzir.each do |chave, valor|
    if valor.class.to_s == "String"
        objeto_traduzir[chave] = traduzirString(valor)
    end
    if valor.class.to_s == "Hash"
        retorno = descer_nivel_hash(valor)
        valor = retorno
    end
end

f = File.open("output.json", 'a+')
f.write(objeto_traduzir.to_json)
f.close
puts "Fim Execucao"